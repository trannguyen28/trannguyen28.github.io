i = -1
stop = 17
while i <= stop:
    i = i + 1
    print (i)
