acc = 11
for i in range (0, 11):
    acc = acc - 1
    print (acc)
