start = 0
stop = 19
for i in range (start, stop):
    print (i)
