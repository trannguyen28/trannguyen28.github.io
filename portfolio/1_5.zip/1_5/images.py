from tkinter import *

root = Tk()

photo = PhotoImage(file="ml.png")
label = Label(root, image=photo)
label.pack()

root.mainloop()
